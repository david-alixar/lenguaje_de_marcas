# II Maquetando con Flex

1. Elementos de maquetación FLEX
2. El contenedor Flex. Propiedades.
3. Elementos flexibles. Ajustando el tamaño.
4. Elementos flexibles. Alineación, justificación y espacio libre.
5. Ejercicio Pŕactico.

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
