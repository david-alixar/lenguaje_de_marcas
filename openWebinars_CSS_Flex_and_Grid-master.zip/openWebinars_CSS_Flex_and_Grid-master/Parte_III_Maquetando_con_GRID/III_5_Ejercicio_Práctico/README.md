## III.5 Ejercicio Pŕactico con GRID

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
