## III Maquetando con GRID

1. Elementos de la maquetación GRID.
2. El contenedor GRID. Propiedades.
3. Elementos GRID. Posición y tamaño.
4. Elementos GRID. Alineación y justificación
5. Ejercicio Práctico.
6. ¿Flex o Grid?

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
