# OpenWebinars_Maquetación_con_FLEX_y_GRID

1. Introducción
2. Maquetando con Flex
3. Maquetando con Grid

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
