# I Introducción

1. Presentación del curso
2. ¿Qué son Flex y Grid?
3. Entorno de Trabajo y Referencias
4. Estructura del resto del curso

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
