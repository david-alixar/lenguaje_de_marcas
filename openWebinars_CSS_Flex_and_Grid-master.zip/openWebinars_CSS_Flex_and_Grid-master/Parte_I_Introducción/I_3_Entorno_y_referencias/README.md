# I.3 Entorno de Trabajo y Referencias

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
