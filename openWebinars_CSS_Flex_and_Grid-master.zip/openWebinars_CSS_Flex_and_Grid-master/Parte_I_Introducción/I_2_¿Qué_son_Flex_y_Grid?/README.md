# I.2 ¿Qué son Flex y Grid?

Curso desarrollado por [pekechis](http://github.com/pekechis) para [OpenWebinars](https://openwebinars.net/)
